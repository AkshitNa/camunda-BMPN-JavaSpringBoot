## This project has been migrated

The `camunda-bpmn-model` repository has been merged with the `camunda-bpm-platform` project. The
source files can be found [here](https://github.com/camunda/camunda-bpm-platform/tree/master/model-api/bpmn-model).

Please submit any future contributions to the source files to the `camunda-bpm-platform` repository.

## License
The source files in this repository are made available under the [Apache License Version 2.0](./LICENSE).

